# YUGA Hanuman studio and trial

Open `blender/Hanuman.blend` in Blender 4.3 or newer for the editable 167-joint hero and eleven clips. `blender/Hanuman-Look-Development.blend` also includes the original scene and the presentation scene with two packed ImageGen inputs. The concept board is a viewport reference, while the generated cloth is wired into the actual scene material. `models/Hanuman.glb` is the exact native runtime export.

Play the original offline game trial from the `game/yuga-hanuman-trial` branch of https://github.com/occult-kranti/ANDOLAN. Import with Godot 4.6.3 and run `godot --path games/yuga-native` from the repository root. Choose Hanuman, Begin Hanuman Trial, then Begin practice. The archive supplies the authoring assets, renders and evidence. The game project and source recipes live in the repository.

`video/Hanuman-Studio-Reel.mp4` has 120 in-place rendered frames at 16 fps. `video/Hanuman-Native-Trial.mp4` has 112 rendered frames at 16 fps and shows the actual trial moving through a scripted input plan. Both reels are silent. The earlier ordinary keyboard and mouse route and the final scripted motion are documented separately. The quality target still needs richer character detail, contact polish and physical GPU qualification.

Review source credit and rights in `licenses`. `SHA256SUMS.txt` identifies the exact payload. The `design` documents link to full relative paths in the repository.
