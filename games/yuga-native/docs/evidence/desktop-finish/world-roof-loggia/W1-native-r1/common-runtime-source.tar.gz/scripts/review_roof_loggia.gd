extends RefCounted
## REVIEW ONLY. Call explicitly in an isolated child after EnvironmentSurfaceFinish.
## Original invented civic loggia; see README/NOTICE. Never loaded by runtime.
const TARGET := "CityArt/block-2-roof"
const ROOT_NAME := "ReviewBlock2RoofLoggia"
const MATERIAL_NAMES := ["Confluence_carved_limestone", "Confluence_transit_indigo"]
const DIMENSIONS := Vector3(13.68, 2.8, 13.68)
const TRIANGLE_BUDGET := 900
var surfaces: Array[SurfaceTool] = []
var solid_faces := PackedVector3Array()
var triangle_counts := [0, 0]

static func configure(world: Node3D) -> Dictionary:
	if not is_instance_valid(world): return {"ok":false,"reason":"invalid_world"}
	if world.get_node_or_null(ROOT_NAME) != null: return {"ok":false,"reason":"already_present"}
	var original := world.get_node_or_null(TARGET) as Node3D
	if original == null or not original.visible: return {"ok":false,"reason":"target_missing_or_hidden"}
	if not original.scale.is_equal_approx(DIMENSIONS): return {"ok":false,"reason":"unexpected_scale"}
	# Reuse active resources, including finish overrides; never duplicate materials.
	var materials: Array[Material] = []
	for wanted in MATERIAL_NAMES:
		var found: Material
		var meshes: Array[Node] = original.find_children("*", "MeshInstance3D", true, false)
		if original is MeshInstance3D: meshes.push_front(original)
		for node in meshes:
			var mesh := node as MeshInstance3D
			if mesh.mesh == null: continue
			for surface in mesh.mesh.get_surface_count():
				var imported := mesh.mesh.surface_get_material(surface)
				if imported != null and imported.resource_name == wanted:
					found = mesh.get_active_material(surface)
		if found == null: return {"ok":false,"reason":"missing_material","material":wanted}
		materials.append(found)
	var builder = new()
	for unused in 2:
		var tool := SurfaceTool.new()
		tool.begin(Mesh.PRIMITIVE_TRIANGLES)
		builder.surfaces.append(tool)
	builder._build()
	if builder.solid_faces.size() / 3 > TRIANGLE_BUDGET:
		return {"ok":false,"reason":"triangle_budget"}
	var combined := ArrayMesh.new()
	for index in 2:
		builder.surfaces[index].generate_tangents()
		builder.surfaces[index].set_material(materials[index])
		builder.surfaces[index].commit(combined)
	var root := Node3D.new()
	root.name = ROOT_NAME
	root.set_meta("review_only", true)
	root.set_meta("original_visibility", original.visible)
	world.add_child(root)
	# Bake nonuniform dimension scale into mesh/shape, keep physics basis unit-scale.
	root.global_transform = Transform3D(original.global_basis.orthonormalized(), original.global_position)
	var mesh := MeshInstance3D.new()
	mesh.name = "LoggiaTwoSharedSurfaces"
	mesh.mesh = combined
	root.add_child(mesh)
	var body := StaticBody3D.new()
	body.name = "LoggiaTruthfulSolid"
	body.collision_layer = 1
	body.collision_mask = 0
	var shape := ConcavePolygonShape3D.new()
	shape.backface_collision = true
	shape.set_faces(builder.solid_faces)
	var holder := CollisionShape3D.new()
	holder.shape = shape
	body.add_child(holder)
	root.add_child(body)
	# Publish replacement only after all resources/geometry exist successfully.
	original.visible = false
	return {"ok":true,"root":root,"original":original,"mesh":mesh,"body":body,
		"triangles":builder.solid_faces.size()/3,"surface_triangles":builder.triangle_counts,
		"materials":materials,"new_materials":0,"new_textures":0,"new_lights":0,
		"mesh_instances":1,"surface_draws_max_per_pass":2,"static_bodies":1,
		"collision_faces_equal_render_faces":true,"automatic_lod":false}

static func remove(world: Node3D) -> void:
	var root := world.get_node_or_null(ROOT_NAME)
	if root == null or not root.get_meta("review_only", false): return
	var original := world.get_node_or_null(TARGET) as Node3D
	if original != null: original.visible = root.get_meta("original_visibility", true)
	world.remove_child(root)
	root.free()

func _build() -> void:
	# One existing roof module only: four upright pairs make three broad bays.
	# Existing Y15 building roof is the walking surface: no new raised threshold.
	for z in [-.30,.30]:
		for x in [-.42,-.14,.14,.42]:
			_box(Vector3(x,.26,z),Vector3(.034,.52,.034),0)
			_box(Vector3(x,.505,z),Vector3(.048,.030,.052),0)
		for x in [-.28,0.0,.28]: _arch(x,z)
	_box(Vector3(0,.825,0),Vector3(.96,.05,.76),0)
	_box(Vector3(0,.865,0),Vector3(1.0,.03,.80),1)
	# A broad oblong hipped cap replaces thin pergola slats; no tiny finials.
	var vertices: Array[Vector3] = []
	for level in [Vector3(.96,.88,.76),Vector3(.80,1.0,.60)]:
		for z in [-1.0,1.0]:
			for x in [-1.0,1.0]: vertices.append(Vector3(x*level.x*.5,level.y,z*level.z*.5))
	for face in [[0,2,3,1],[4,5,7,6],[0,1,5,4],[1,3,7,5],[3,2,6,7],[2,0,4,6]]:
		# Blender builder recalculates closed-mesh normals; direct mesh must wind outward.
		_quad(vertices[face[3]],vertices[face[2]],vertices[face[1]],vertices[face[0]],1)

func _arch(x: float,z: float) -> void:
	# Six elliptical annular prisms. The same triangles define visible/solid stone.
	var segments := 12
	for index in segments:
		var points: Array[Vector3] = []
		for depth in [-.018,.018]:
			for radius in [Vector2(.113,.24),Vector2(.14,.28)]:
				for angle in [PI*index/segments,PI*(index+1)/segments]:
					points.append(Vector3(x+cos(angle)*radius.x,.52+sin(angle)*radius.y,z+depth))
		for face in [[0,1,3,2],[4,6,7,5],[0,4,5,1],[2,3,7,6]]:
			_quad(points[face[0]],points[face[1]],points[face[2]],points[face[3]],0)
		if index == 0: _quad(points[0],points[2],points[6],points[4],0)
		if index == segments-1: _quad(points[1],points[5],points[7],points[3],0)

func _box(center: Vector3,size: Vector3,material: int) -> void:
	var points: Array[Vector3] = []
	for y in [-1.0,1.0]:
		for z in [-1.0,1.0]:
			for x in [-1.0,1.0]: points.append(center+Vector3(x,y,z)*size*.5)
	for face in [[0,1,3,2],[4,6,7,5],[0,4,5,1],[2,3,7,6],[0,2,6,4],[1,5,7,3]]:
		_quad(points[face[0]],points[face[1]],points[face[2]],points[face[3]],material)

func _quad(a:Vector3,b:Vector3,c:Vector3,d:Vector3,material:int) -> void:
	_triangle(a,b,c,material)
	_triangle(a,c,d,material)

func _triangle(a:Vector3,b:Vector3,c:Vector3,material:int) -> void:
	var points := [a*DIMENSIONS,b*DIMENSIONS,c*DIMENSIONS]
	var normal: Vector3=(points[1]-points[0]).cross(points[2]-points[0]).normalized()
	for index in 3:
		var p: Vector3=points[index]
		var uv: Vector2
		var unit: Vector3=[a,b,c][index]
		if absf(normal.y) > maxf(absf(normal.x),absf(normal.z)): uv=Vector2(unit.x,unit.z)*7.0
		elif absf(normal.x) > absf(normal.z): uv=Vector2(unit.y,unit.z)*7.0
		else: uv=Vector2(unit.x,unit.y)*7.0
		surfaces[material].set_normal(normal)
		surfaces[material].set_uv(uv)
		surfaces[material].add_vertex(p)
		solid_faces.append(p)
	triangle_counts[material]+=1
