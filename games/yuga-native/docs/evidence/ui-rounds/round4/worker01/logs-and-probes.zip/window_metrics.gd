extends SceneTree
const SHELL=preload("res://scripts/launch_shell.gd")
func _initialize() -> void:call_deferred("run")
func frames() -> void:
	for unused in 5:await process_frame
func run() -> void:
	var shell:=SHELL.new();root.add_child(shell);await frames()
	for row in [[Vector2i(1280,720),1.0],[Vector2i(960,540),1.0],[Vector2i(640,360),1.0],[Vector2i(960,540),2.0],[Vector2i(640,360),2.0],[Vector2i(480,320),2.0]]:
		root.size=row[0];root.content_scale_factor=row[1];await frames()
		print(JSON.stringify({"window":str(root.size),"scale":root.content_scale_factor,"min_size":str(root.min_size),"content_scale_size":str(root.content_scale_size),"logical":str(root.get_visible_rect()),"shell":str(shell.size),"card":str(shell.card.get_global_rect()),"minimum":str(shell.card.get_combined_minimum_size())}))
	quit()
