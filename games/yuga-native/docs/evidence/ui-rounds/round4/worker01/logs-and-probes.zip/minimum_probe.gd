extends SceneTree
func _initialize() -> void:
	root.min_size=Vector2i(960,540)
	root.size=Vector2i(64,64)
	print(root.size)
	quit()
