extends SceneTree
func _initialize() -> void:
	var out:={}
	for label in ["FABRIK3D","CCDIK3D","Skeleton3D"]:
		out[label]=ClassDB.class_get_method_list(label,false)
	var node:=FABRIK3D.new();node.set_setting_count(1)
	out["FABRIK3D_props"]=node.get_property_list();node.free()
	FileAccess.open("/workspace/scratch/visual-round4/role-07/api.json",FileAccess.WRITE).store_string(JSON.stringify(out,"  "));quit()
