extends SceneTree
func _initialize() -> void:call_deferred("run")
func find_rig(n:Node) -> Skeleton3D:
	if n is Skeleton3D:return n
	for c in n.get_children():
		var r:=find_rig(c)
		if r:return r
	return null
func run() -> void:
	var model:Node=load("res://assets/heroes/rama-hero.glb").instantiate();root.add_child(model)
	var rig:=find_rig(model);rig.modifier_callback_mode_process=Skeleton3D.MODIFIER_CALLBACK_MODE_PROCESS_MANUAL
	var target:=Node3D.new();target.name="Target";rig.add_child(target)
	var solver:=FABRIK3D.new();solver.set_setting_count(1);rig.add_child(solver)
	solver.set_root_bone_name(0,"upperleg01.L");solver.set_end_bone_name(0,"foot.L");solver.set_target_node(0,solver.get_path_to(target));solver.set_extend_end_bone(0,false)
	solver.set_max_iterations(32)
	var foot:=rig.find_bone("foot.L");var before:=rig.get_bone_global_pose(foot).origin;target.position=before+Vector3(.05,.1,.07)
	print("jointcount ",solver.get_joint_count(0)," target ",target.position," before ",before," hascall ",solver.has_method("_process_modification_with_delta"))
	solver.modification_processed.connect(func():print("inside callback ",rig.get_bone_global_pose(foot).origin))
	rig.advance(0.016)
	await process_frame
	await process_frame
	print("afteradvance ",rig.get_bone_global_pose(foot).origin)
	model.free();quit()
