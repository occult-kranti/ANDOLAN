extends SceneTree
func _initialize()->void:call_deferred("run")
func find_rig(n:Node)->Skeleton3D:
	if n is Skeleton3D:return n
	for c in n.get_children():
		var r:=find_rig(c)
		if r:return r
	return null
func run()->void:
	var model:Node3D=load("res://assets/heroes/rama-hero.glb").instantiate();root.add_child(model);var rig:=find_rig(model);print("RIG_GLOBAL ",rig.global_transform);print("IDENTITY ",rig.global_transform.is_equal_approx(Transform3D.IDENTITY));model.free();quit()
