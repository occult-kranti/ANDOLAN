extends "res://scripts/rama_motion.gd"
var record_enabled:=false
var queries:={}
func _solve_leg(side:String,target:Vector3)->void:
	if not record_enabled:
		super._solve_leg(side,target)
		return
	var before:Array[Transform3D]=[]
	for i in rig.get_bone_count():before.append(rig.get_bone_pose(i))
	super._solve_leg(side,target)
	var after:Array[Transform3D]=[]
	for i in rig.get_bone_count():after.append(rig.get_bone_global_pose(i))
	queries[side]={"side":side,"target":target,"before":before,"baseline":after}
