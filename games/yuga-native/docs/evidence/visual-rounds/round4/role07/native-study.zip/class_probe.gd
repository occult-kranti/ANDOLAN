extends SceneTree
func _initialize() -> void:
	var report:={"engine":Engine.get_version_info(),"classes":{}}
	for label in ["SkeletonModifier3D","SkeletonIK3D","TwoBoneIK3D","FABRIK3D","CCDIK3D","ChainIK3D","IKModifier3D"]:
		var row:={"exists":ClassDB.class_exists(label),"instantiate":ClassDB.can_instantiate(label)}
		if row.exists:
			row["parent"]=ClassDB.get_parent_class(label)
			row["methods"]=ClassDB.class_get_method_list(label,true)
			row["properties"]=ClassDB.class_get_property_list(label,true)
		report.classes[label]=row
	FileAccess.open("/workspace/scratch/visual-round4/role-07/classes.json",FileAccess.WRITE).store_string(JSON.stringify(report,"  "))
	quit()
