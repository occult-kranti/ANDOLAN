extends SceneTree
const REC=preload("/workspace/scratch/visual-round4/role-07/query_recorder.gd")
const FIXTURE=preload("/workspace/ANDOLAN/scratch/visual-round4/role-05/probe-continuity.gd")
var queries:Array[Dictionary]=[]
var samples:Array[Dictionary]=[]
var foot_vertices:Array[Dictionary]=[]
var captured:Array[Transform3D]=[]
var callback_count:=0
var native_tape:Array[Dictionary]=[]
var input_before:={}
var report_path:="/workspace/scratch/visual-round4/role-07/comparator-r5.json"
func _initialize()->void:call_deferred("run")
func find_kind(n:Node,k:String)->Node:
	if n.is_class(k):return n
	for c in n.get_children():
		var r:=find_kind(c,k)
		if r:return r
	return null
func skin_collect(n:Node,rig:Skeleton3D)->void:
	if n is MeshInstance3D and n.skin:
		var binds:Array[Dictionary]=[]
		for i in n.skin.get_bind_count():
			var name_:String=n.skin.get_bind_name(i)
			binds.append({"bone":rig.find_bone(name_) if not name_.is_empty() else n.skin.get_bind_bone(i),"inverse":n.skin.get_bind_pose(i)})
		for s in n.mesh.get_surface_count():
			var a:Array=n.mesh.surface_get_arrays(s);var verts:PackedVector3Array=a[Mesh.ARRAY_VERTEX];var joints:PackedInt32Array=a[Mesh.ARRAY_BONES];var weights:PackedFloat32Array=a[Mesh.ARRAY_WEIGHTS]
			var stride:int=joints.size()/verts.size()
			for i in range(0,verts.size(),16):
				var sums:={"L":0.0,"R":0.0};var influences:Array[Dictionary]=[]
				for slot in stride:
					var w:float=weights[i*stride+slot]
					if w<=0:continue
					var b:Dictionary=binds[joints[i*stride+slot]];var bn:String=rig.get_bone_name(b.bone)
					influences.append({"bone":b.bone,"point":b.inverse*verts[i],"weight":w})
					if bn.begins_with("foot") or bn.begins_with("toe"):
						sums["L" if bn.ends_with(".L") else "R"]+=w
				if maxf(sums.L,sums.R)>.5:foot_vertices.append({"side":"L" if sums.L>sums.R else "R","mesh":String(n.name),"surface":s,"vertex":i,"combined_foot_toe_weight":maxf(sums.L,sums.R),"influences":influences})
	for c in n.get_children():skin_collect(c,rig)
func floor_witness(globals:Array[Transform3D],side:String)->Dictionary:
	var result:={"y":INF}
	for v in foot_vertices:
		if v.side!=side:continue
		var point:=Vector3.ZERO
		for inf in v.influences:point+=(globals[inf.bone]*inf.point)*inf.weight
		if point.y<result.y:result={"y":point.y,"point":[point.x,point.y,point.z],"mesh":v.mesh,"surface":v.surface,"vertex":v.vertex,"combined_foot_toe_weight":v.combined_foot_toe_weight}
	return result
func source_pins()->Dictionary:
	var result:={}
	for path in ["res://assets/heroes/rama-hero.glb","res://assets/heroes/rama-hero.glb.import","res://.godot/imported/rama-hero.glb-e90b8f8a0719fdd1ab2b89459efcbdac.scn","res://assets/animations/rama_hero_motion.tres","res://scripts/rama_motion.gd","/workspace/ANDOLAN/scratch/visual-round4/role-05/probe-continuity.gd","/workspace/scratch/visual-round4/role-07/query_recorder.gd",get_script().resource_path]:result[path]=FileAccess.get_sha256(path)
	return result
func record_queries()->void:
	var fixture=FIXTURE.new()
	for hz in [30.0,60.0,120.0]:
		for scenario in ["accelerated_reversal","reversal","strafe","backpedal","stationary_aim","hitch","reset","action_cancel"]:
			var model:Node3D=load("res://assets/heroes/rama-hero.glb").instantiate();root.add_child(model)
			var motion=REC.new();assert(motion.configure(model,find_kind(model,"AnimationPlayer")));motion.active=false
			motion.rig.modifier_callback_mode_process=Skeleton3D.MODIFIER_CALLBACK_MODE_PROCESS_MANUAL
			if foot_vertices.is_empty():skin_collect(model,motion.rig)
			var velocity:=Vector3.ZERO
			for frame in int(hz*1.6):
				var state:Dictionary=fixture.scenario_state(scenario,frame,hz)
				if scenario=="accelerated_reversal":
					velocity.x=move_toward(velocity.x,Vector3(state.velocity).x,38.0/hz);velocity.z=move_toward(velocity.z,Vector3(state.velocity).z,38.0/hz);state.velocity=velocity
				if scenario=="reset" and frame==int(hz*.8):motion.cancel("native comparator reset");model.position=Vector3.ZERO
				if scenario=="action_cancel":
					if frame==int(hz*.2):motion.request_action("kodanda",.18,.22)
					if frame==int(hz*.3):motion.cancel_action("independent windup interruption")
					if frame==int(hz*.5):motion.request_action("piercing_dawn",.18,.22)
					if frame==int(hz*.9):motion.release_action("piercing_dawn")
				var dt:float=.08 if scenario=="hitch" and frame==int(hz*.8) else 1.0/hz
				model.position+=Vector3(state.velocity)*dt
				motion.record_enabled=frame%int(hz*.2)==0 or frame==int(hz*.8)-1
				motion.queries.clear();motion.update_motion(dt,state);motion.evaluate_pose()
				if motion.record_enabled:
					for side in motion.queries:
						var q:Dictionary=motion.queries[side];q.merge({"scenario":scenario,"hz":hz,"frame":frame,"dt":dt,"planted":motion.foot_locks[side],"clock":[motion.phase,motion.locomotion_age,motion.action_elapsed,motion.release_count,motion.cancel_count]});queries.append(q)
			model.free()
	fixture.free()
func run()->void:
	input_before=source_pins()
	record_queries();print("Recorded ",queries.size()," queries, foot subset ",foot_vertices.size())
	var model:Node3D=load("res://assets/heroes/rama-hero.glb").instantiate();root.add_child(model);var rig:Skeleton3D=find_kind(model,"Skeleton3D")
	rig.modifier_callback_mode_process=Skeleton3D.MODIFIER_CALLBACK_MODE_PROCESS_MANUAL
	var target:=Node3D.new();target.name="IndependentIKTarget";rig.add_child(target)
	for kind in ["FABRIK3D","CCDIK3D"]:
		var solvers:={}
		for side in ["L","R"]:
			var solver:SkeletonModifier3D=ClassDB.instantiate(kind);solver.active=false;solver.set_setting_count(1);solver.set_root_bone_name(0,"upperleg01."+side);solver.set_end_bone_name(0,"foot."+side);rig.add_child(solver);solver.set_extend_end_bone(0,false);solver.set_target_node(0,solver.get_path_to(target));solver.set_max_iterations(32);solver.set_angular_delta_limit(PI);solvers[side]=solver
			solver.modification_processed.connect(func():
				callback_count+=1;captured.clear()
				for i in rig.get_bone_count():captured.append(rig.get_bone_global_pose(i)))
		for q in queries:
			var solver:SkeletonModifier3D=solvers[q.side]
			solver.active=false
			solver.set_setting_count(0);solver.set_setting_count(1);solver.set_root_bone_name(0,"upperleg01."+q.side);solver.set_end_bone_name(0,"foot."+q.side);solver.set_extend_end_bone(0,false);solver.set_target_node(0,solver.get_path_to(target))
			for i in rig.get_bone_count():rig.set_bone_pose(i,q.before[i])
			target.position=q.target
			captured.clear();var old_count:=callback_count;solver.active=true;rig.advance(q.dt)
			await process_frame
			await process_frame
			solver.active=false
			assert(captured.size()==164)
			var foot:=rig.find_bone("foot."+q.side);var joints:Array[int]=[]
			for part in ["upperleg01.","upperleg02.","lowerleg01.","lowerleg02.","foot."]:joints.append(rig.find_bone(part+q.side))
			var length_error:=0.0;var joint_difference:=0.0;var finite:=true
			for j in joints.size():
				finite=finite and captured[joints[j]].is_finite();joint_difference=maxf(joint_difference,captured[joints[j]].origin.distance_to(q.baseline[joints[j]].origin))
				if j>0:length_error=maxf(length_error,absf(captured[joints[j]].origin.distance_to(captured[joints[j-1]].origin)-q.before[joints[j]].origin.length()))
			var base_error:float=q.baseline[foot].origin.distance_to(q.target);var native_error:float=captured[foot].origin.distance_to(q.target)
			var orientation:float=captured[foot].basis.get_rotation_quaternion().angle_to(q.baseline[foot].basis.get_rotation_quaternion())
			var base_floor:=floor_witness(q.baseline,q.side);var native_floor:=floor_witness(captured,q.side)
			var outside_error:=0.0
			for i in rig.get_bone_count():
				var bone_name:String=rig.get_bone_name(i)
				if (bone_name.contains("leg") or bone_name.begins_with("foot") or bone_name.begins_with("toe")) and bone_name.ends_with("."+q.side):continue
				outside_error=maxf(outside_error,captured[i].origin.distance_to(q.baseline[i].origin))
			native_tape.append({"solver":kind,"scenario":q.scenario,"hz":q.hz,"frame":q.frame,"side":q.side,"globals":captured.duplicate()})
			var row:={"solver":kind,"scenario":q.scenario,"hz":q.hz,"frame":q.frame,"side":q.side,"planted":q.planted,"chain_joints":solver.get_joint_count(0),"callback_count":callback_count-old_count,"finite":finite,"baseline_target_error_m":base_error,"native_target_error_m":native_error,"segment_length_error_m":length_error,"max_joint_difference_m":joint_difference,"foot_orientation_difference_rad":orientation,"baseline_foot_subset_min_y_m":base_floor.y,"native_foot_subset_min_y_m":native_floor.y,"baseline_floor_witness":base_floor,"native_floor_witness":native_floor,"outside_leg_origin_error_m":outside_error,"unchanged_upstream_clock":q.clock}
			samples.append(row)
		print(kind," complete ",samples.size())
		for solver in solvers.values():solver.free()
	var bones:Array[String]=[];var rests:Array[Transform3D]=[]
	for i in rig.get_bone_count():bones.append(rig.get_bone_name(i));rests.append(rig.get_bone_rest(i))
	var tape:=FileAccess.open("/workspace/scratch/visual-round4/role-07/query-and-native-tape-r5.bin",FileAccess.WRITE);tape.store_var({"queries":queries,"native":native_tape,"bones":bones,"rests":rests,"foot_vertices":foot_vertices});tape.close()
	model.free()
	var result:={"task":"R4-07","native_internal_state_reset_per_query":true,"engine":Engine.get_version_info(),"input_before":input_before,"input_after":source_pins(),"query_tape_sha256":FileAccess.get_sha256("/workspace/scratch/visual-round4/role-07/query-and-native-tape-r5.bin"),"query_count":queries.size(),"foot_subset_count":foot_vertices.size(),"samples":samples,"scope":"Exact pre-solve actual-rig query replay, single active native writer, five joints/four segments. Each selected last per-side solve starts from incumbent authored pose/target. Native output captured inside modification_processed before Skeleton3D restores poses. This is not integrated controller continuity, full-skin floor, rendering or promotion acceptance. Aggregate foot/toe weights >.5, source-order every16th vertices."}
	var f:=FileAccess.open(report_path,FileAccess.WRITE);f.store_string(JSON.stringify(result,"\t"));f.close();quit()
