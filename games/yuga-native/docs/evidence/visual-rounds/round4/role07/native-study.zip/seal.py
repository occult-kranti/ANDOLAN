from pathlib import Path
import hashlib,json,math,statistics,zipfile
p=Path('/workspace/scratch/visual-round4/role-07');out=Path('/workspace/ANDOLAN/games/yuga-native/docs/evidence/visual-rounds/round4/role07');out.mkdir(parents=True,exist_ok=True)
d=json.loads((p/'comparator-r5.json').read_text());checks=[]
def check(name,ok):checks.append({'name':name,'passed':bool(ok)})
check('before and after raw/import/controller/library/fixture pins exact',d['input_before']==d['input_after'])
check('exact approved R2 raw near source',d['input_before']['res://assets/heroes/rama-hero.glb']=='140f8ff3695bb3d28bd894cb74bca8cd5f1756bbffcf59dad6c4630f377c351a')
check('exact source-verified R2 imported scene',d['input_before']['res://.godot/imported/rama-hero.glb-e90b8f8a0719fdd1ab2b89459efcbdac.scn']=='75f6ed7971c540b464ce1bc4533ed50871ba695d8f4769efc7520798a6d69a28')
check('279 pre-solve queries and 558 solver outputs',d['query_count']==279 and len(d['samples'])==558)
check('all requested 30 60 120 rates represented',{r['hz'] for r in d['samples']}=={30,60,120})
check('both native algorithms represented',{r['solver'] for r in d['samples']}=={'FABRIK3D','CCDIK3D'})
check('five joints four existing segments on every output',all(r['chain_joints']==5 for r in d['samples']))
check('one active native callback per query',all(r['callback_count']==1 for r in d['samples']))
check('finite chain transforms',all(r['finite'] for r in d['samples']))
check('native segment lengths preserved within one micrometre',max(r['segment_length_error_m'] for r in d['samples'])<1e-6)
check('non-leg origins preserved within one micrometre',max(r['outside_leg_origin_error_m'] for r in d['samples'])<1e-6)
check('native internal settings reset per query',d['native_internal_state_reset_per_query'])
check('clean final native log',not any(x in (p/'comparator-r5.log').read_text() for x in ['ERROR:','WARNING:']))
check('exact serialized pose tape digest',hashlib.sha256((p/'query-and-native-tape-r5.bin').read_bytes()).hexdigest()==d['query_tape_sha256'])
old=json.loads((p/'comparator-r4.json').read_text());check('resetting native cache reproduces every prior metric',old['samples']==d['samples'])
summary=[]
for solver in ['FABRIK3D','CCDIK3D']:
 for hz in [30,60,120]:
  for name in ['accelerated_reversal','reversal','strafe','backpedal','stationary_aim','hitch','reset','action_cancel']:
   rows=[r for r in d['samples'] if r['solver']==solver and r['hz']==hz and r['scenario']==name];worst=min(rows,key=lambda r:r['native_foot_subset_min_y_m'])
   summary.append({'solver':solver,'hz':hz,'scenario':name,'selected_queries':len(rows),'selected_planted_queries':sum(r['planted'] for r in rows),'baseline_endpoint_max_mm':max(r['baseline_target_error_m'] for r in rows)*1000,'native_endpoint_max_mm':max(r['native_target_error_m'] for r in rows)*1000,'baseline_sampled_foot_min_mm':min(r['baseline_foot_subset_min_y_m'] for r in rows)*1000,'native_sampled_foot_min_mm':min(r['native_foot_subset_min_y_m'] for r in rows)*1000,'maximum_foot_orientation_difference_deg':max(r['foot_orientation_difference_rad'] for r in rows)*180/math.pi,'worst_floor_witness':worst})
result={'task':'R4-07','probe_integrity_passed':all(c['passed'] for c in checks),'integrity_check_count':len(checks),'candidate_accepted':False,'production_changes':[],'checks':checks,'summary':summary,'input_before':d['input_before'],'input_after':d['input_after'],'foot_sample_count':d['foot_subset_count'],'foot_sample_rule':'sum of same-side foot/toe influences >.5, every16th source vertex, all bound meshes; not all sole vertices','query_tape':{'sha256':d['query_tape_sha256'],'bytes':(p/'query-and-native-tape-r5.bin').stat().st_size,'format':'Godot FileAccess.store_var; load via get_var(false). Contains all164 named/rest bones, every recorded local prepose and incumbent global postpose/target/state clock, every native global output, and sampled skin source IDs/influences.'},'scope':'Source and imported-resource-bound local solver comparison. No full-controller continuity, floor/contact coverage, C0/C1 release, authoritative-gameplay timing, normal-speed render, or R7 acceptance.'}
(out/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
(out/'source-contract.json').write_text(json.dumps({'engine':d['engine'],'official_sources':{f.name:{'url':'https://raw.githubusercontent.com/godotengine/godot/4.6.3-stable/scene/3d/'+f.name,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in p.glob('*.cpp')},'classes':json.loads((p/'classes.json').read_text()),'native_phase':'Skeleton3D.advance queues deferred modifier phase. Capture native result in modification_processed; outside the phase the skeleton restores unmodified poses. No callable synchronous native _process_modification_with_delta method.','failure_probes':['invoke-probe.log','comparator-r1.log','comparator-r2.log']},indent=2)+'\n')
with zipfile.ZipFile(out/'native-study.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for f in sorted(p.iterdir()):
  if f.is_file():z.write(f,f.name)
receipt={'task':'R4-07','probe_integrity_passed':result['probe_integrity_passed'],'integrity_check_count':len(checks),'native_candidate_accepted':False,'command':'taskset -c 2 env LP_NUM_THREADS=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 godot --headless --path /workspace/scratch/visual-round3/capture-baseline-project-r1 --script /workspace/scratch/visual-round4/role-07/native_comparator.gd','execution_exit_code':0,'final_log_clean':True,'archive':{'bytes':(out/'native-study.zip').stat().st_size,'sha256':hashlib.sha256((out/'native-study.zip').read_bytes()).hexdigest()},'failed_runs_preserved':['Unavailable virtual invoke (terminated owned errored SceneTree)','comparator-r1 parse failure: dt required explicit float','comparator-r2 chain reassignment emitted errors while changing L to R root/end; superseded by fixed separate inactive-side nodes'],'source_commit_at_review':'495fae3aad59bfcce22506cc27f9d042741cd4ab','asset_scope':'Frozen approved R2 capture project; current canonical R7 promotion is separate.'};(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'checks':len(checks),'integrity_passed':result['probe_integrity_passed'],'candidate_accepted':False,'archive_bytes':receipt['archive']['bytes']}))
