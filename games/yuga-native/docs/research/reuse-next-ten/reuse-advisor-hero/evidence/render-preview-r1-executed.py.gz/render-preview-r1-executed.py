"""Four matched actual textured frames from the exact frozen MPFB authoring study."""
import argparse,json,time,sys,hashlib
from pathlib import Path
import bpy

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 parser=argparse.ArgumentParser();parser.add_argument('--receipt',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args(sys.argv[sys.argv.index('--')+1:]);source=json.loads(args.receipt.read_text());master=Path(source['scene']['path']);assert sha(master)==source['scene']['sha256'];args.output.mkdir(parents=True,exist_ok=False);bpy.ops.wm.open_mainfile(filepath=str(master));scene=bpy.context.scene;scene.render.threads_mode='FIXED';scene.render.threads=2;baseline=bpy.data.objects['APPROVED BASELINE Rama'];candidate=bpy.data.objects['MPFB nape preview Rama'];donor=bpy.data.objects['MPFB CC0 fitted rear guides'];start=time.monotonic();frames=[]
 for view in ['profile','rear']:
  scene.camera=bpy.data.objects['MPFB locked '+view]
  for variant in ['baseline','candidate']:
   baseline.hide_render=variant!='baseline';candidate.hide_render=variant!='candidate';donor.hide_render=variant!='candidate';frame=args.output/(view+'-'+variant+'.png');scene.render.filepath=str(frame);begin=time.monotonic();bpy.ops.render.render(write_still=True);frames.append({'path':frame.name,'view':view,'variant':variant,'sha256':sha(frame),'bytes':frame.stat().st_size,'elapsed_seconds':time.monotonic()-begin,'camera_matrix':[list(row) for row in scene.camera.matrix_world]})
 report={'schema_version':1,'scope':'Actual matched textured close profile/rear preview, not native skin/pose/LOD or final art acceptance','source_receipt_sha256':sha(args.receipt),'master_sha256':sha(master),'donor_sha256':source['donor_sha256'],'canonical_source_sha256':source['source_sha256'],'script_sha256':sha(__file__),'reader':bpy.app.version_string,'renderer':'Cycles CPU','threads':2,'samples':scene.cycles.samples,'resolution':[scene.render.resolution_x,scene.render.resolution_y],'exposure':scene.view_settings.exposure,'material_override':str(scene.view_layers[0].material_override),'frames':frames,'positive_completion':len(frames)==4 and sha(master)==source['scene']['sha256'],'elapsed_seconds':time.monotonic()-start,'canonical_promoted':False,'runtime_promoted':False};(args.output/'render-receipt.json').write_text(json.dumps(report,indent=2)+'\n');print('MPFB_RENDER='+json.dumps(report,separators=(',',':')))
if __name__=='__main__':main()
