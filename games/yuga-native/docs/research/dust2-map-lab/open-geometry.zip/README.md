# Atelier and Trident — editable Xonotic arena geometry

Atelier is credited to ShadoW, Mirio and Debugger. Trident is by proraide. Each map source and the derived OBJ/MTL geometry is supplied under its upstream GPL-3.0-or-later terms. The editable `.map`, upstream license declaration, credits and full GPL text accompany the Blender exports. Map source text is unchanged from Xonotic revision `cc92d86adae0d8a795a3bf5634093593a86bdb53`.

On 26 November 2026 the YUGA map team compiled the original map files with NetRadiant-Custom 20260114 and converted the results to OBJ and MTL. Atelier has 45,930 OBJ faces. Trident has 6,920. The material files retain the original slot names and texture references. Import a model into Blender via File → Import → Wavefront (.obj), then assign your own materials to the slots. The separate Xonotic texture and prop packages were not part of this geometry build. For route or collision edits, open the corresponding `.map` in NetRadiant and build again.

Upstream map repository and commit: https://github.com/xonotic/xonotic-maps.pk3dir/tree/cc92d86adae0d8a795a3bf5634093593a86bdb53/maps
Compiler and conversion commands: https://github.com/occult-kranti/ANDOLAN/blob/game/yuga-hanuman-trial/games/yuga-native/docs/research/dust2-map-lab/rust-and-cod.md#existing-map-geometry-with-explicit-reuse-terms
