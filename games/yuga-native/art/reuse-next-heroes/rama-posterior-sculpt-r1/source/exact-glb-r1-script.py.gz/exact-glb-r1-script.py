"""Carry the approved-hair sculpt through a sparse original-byte GLB patch.

All indices, UVs, images, JSON, joints, weights, inverse binds and animation
bytes remain exact. No official exporter reorders or repacks the original.
"""
import argparse,hashlib,json,math,struct,sys
from pathlib import Path
import bpy

SOURCE_SHA='db4b2ec7a14cad72299d462c1265374f615d5e9d8b8852c4669e1f960f78245e'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def parse(raw):
 assert struct.unpack_from('<III',raw)==(0x46546c67,2,len(raw));offset=12;doc=None;binary=None
 while offset<len(raw):
  n,t=struct.unpack_from('<II',raw,offset);offset+=8
  if t==0x4e4f534a:doc=json.loads(raw[offset:offset+n])
  if t==0x004e4942:binary=offset
  offset+=n
 assert doc is not None and binary is not None;return doc,binary
def attribute(doc,binary,index):
 a=doc['accessors'][index];v=doc['bufferViews'][a['bufferView']];assert a['type']=='VEC3' and a['componentType']==5126
 return binary+v.get('byteOffset',0)+a.get('byteOffset',0),v.get('byteStride',12),a['count']
def main():
 p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--scene',type=Path,required=True);p.add_argument('--sculpt-report',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args(sys.argv[sys.argv.index('--')+1:]);r=json.loads(a.sculpt_report.read_text());assert sha(a.source)==SOURCE_SHA;assert sha(a.scene)==r['scene']['sha256'];a.output.mkdir(parents=True,exist_ok=False);raw=a.source.read_bytes();doc,binary=parse(raw);hair={i for i,m in enumerate(doc['materials']) if m.get('name')=='Swept black hair'};primitives=[p for mesh in doc['meshes'] for p in mesh['primitives'] if p.get('material') in hair];assert len(primitives)==1;primitive=primitives[0];po,ps,count=attribute(doc,binary,primitive['attributes']['POSITION']);no,ns,nn=attribute(doc,binary,primitive['attributes']['NORMAL']);assert count==nn
 bpy.ops.wm.open_mainfile(filepath=str(a.scene.resolve()));baseline=bpy.data.objects['APPROVED BASELINE Rama'];candidate=bpy.data.objects['W3 posterior-hair sculpt CANDIDATE'];mesh=baseline.data;hair_mats={i for i,m in enumerate(mesh.materials) if m.name=='Swept black hair'};hair_ids=sorted({v for p in mesh.polygons if p.material_index in hair_mats for v in p.vertices});assert len(hair_ids)==count
 deps=bpy.context.evaluated_depsgraph_get();bpy.context.view_layer.update();evaluated=candidate.evaluated_get(deps);after=evaluated.to_mesh(preserve_all_data_layers=True,depsgraph=deps);assert len(after.vertices)==len(mesh.vertices)
 # Source accessor order must be proven, never guessed from approximate nearest-neighbor positions.
 max_mapping=0.
 for i,vertex_id in enumerate(hair_ids):
  gx,gy,gz=struct.unpack_from('<3f',raw,po+i*ps);co=mesh.vertices[vertex_id].co;distance=math.dist((gx,-gz,gy),co);max_mapping=max(max_mapping,distance)
 assert max_mapping<1e-7,('Hair accessor/Blender order differs',max_mapping)
 normals={}
 for face in after.polygons:
  if face.material_index not in hair_mats:continue
  for li in face.loop_indices:
   vertex_id=after.loops[li].vertex_index;n=after.corner_normals[li].vector.copy()
   if vertex_id in normals:assert (normals[vertex_id]-n).length<2e-5
   else:normals[vertex_id]=n
 patch=bytearray(raw);allowed=bytearray(len(raw));delta=[];max_delta=0.
 for i,vertex_id in enumerate(hair_ids):
  old=mesh.vertices[vertex_id].co;new=after.vertices[vertex_id].co;distance=(old-new).length
  if distance<=1e-8:continue
  assert vertex_id in set(r['selected_vertex_ids']);assert .018<old.y and old.z<1.79;assert distance<.1;normal=normals[vertex_id].normalized();position=(new.x,new.z,-new.y);normal_glb=(normal.x,normal.z,-normal.y);struct.pack_into('<3f',patch,po+i*ps,*position);struct.pack_into('<3f',patch,no+i*ns,*normal_glb);allowed[po+i*ps:po+i*ps+12]=b'\1'*12;allowed[no+i*ns:no+i*ns+12]=b'\1'*12;delta.append({'hair_accessor_vertex':i,'blender_vertex':vertex_id,'position':position,'normal':normal_glb});max_delta=max(max_delta,distance)
 evaluated.to_mesh_clear();assert delta;differences=sum(x!=y for x,y in zip(raw,patch));assert all(allowed[i] for i,(x,y) in enumerate(zip(raw,patch)) if x!=y);assert parse(patch)[0]==doc;target=a.output/'rama-hair-sculpt-isolated.glb';target.write_bytes(patch)
 proof={'schema_version':1,'scope':'Sparse hair-only exact-byte runtime candidate, not native pose/LOD or final art acceptance.','source_sha256':SOURCE_SHA,'scene_sha256':sha(a.scene),'sculpt_report_sha256':sha(a.sculpt_report),'script_sha256':sha(__file__),'candidate':{'path':str(target),'bytes':len(patch),'sha256':sha(target)},'source_bytes':len(raw),'hair_accessor_vertices':count,'changed_vertices':len(delta),'changed_bytes':differences,'max_displacement_metres':max_delta,'max_exact_mapping_error':max_mapping,'all_other_bytes_exact':True,'preserved':['container JSON and length','triangle/index accessors','all UV/color-alpha arrays','all embedded image bytes','all material nodes/references','JOINTS/WEIGHTS accessors','inverse bind matrices','skin joints and nodes','animation samplers/channels','all nonhair POSITION/NORMAL bytes','all untouched hair POSITION/NORMAL bytes'],'delta':delta,'source_file_unchanged':sha(a.source)==SOURCE_SHA,'runtime_promoted':False,'artistic_scope':'W1 conditional go as bounded editable sculpt improvement; broad parallel panels remain.','native_reimport_pose_and_lod_checks':'pending','positive_completion':True}
 (a.output/'patch-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({k:v for k,v in proof.items() if k!='delta'},indent=2))
if __name__=='__main__':main()
